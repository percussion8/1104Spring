package com.Spring1030.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.Spring1030.domain.BoardVO;
import com.Spring1030.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTest {
	@Setter(onMethod_=@Autowired)
	private BoardMapper mapper;
	
	@Test
	public void testGetList() {
		mapper.getList().forEach(i-> log.info(i));
		//반복문 활용하세요
		List<BoardVO> vos = mapper.getList();
		for(int i=0; i<vos.size(); i++) {
			log.info(vos.get(i));
		}
		
		//advancedFor
		for(BoardVO vo : mapper.getList()) {
			log.info(vo);
			log.info("이름만 출력" + vo.getWriter());
		}
	}
	
	@Test
	public void testInsert() {
		BoardVO board = new BoardVO();
		board.setTitle("새로 작성하는 글");
		board.setContent("새로 작성하는 내용");
		board.setWriter("박성연 새로작성하는 작가");
		mapper.insert(board);
		
	}
	
	@Test
    public void testSelect() {
       BoardVO board = mapper.read(14L);
       log.info(board);
       
    }
    
    @Test
    public void testDelete() {
       log.info("Delete : " +  mapper.delete(27L));
    }
    
    @Test
    public void testUpdate() {
       BoardVO board = new BoardVO();
       //실행전 존재하는 번호인지 확인할 것 
       board.setBno(15L);
       board.setTitle("수정전 제목");
       board.setContent("수정된 내용");
       board.setWriter("user00");
       
       int count = mapper.update(board);
       log.info("update count : " + count);

    }


}
