package com.Spring1030.controller;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.Spring1030.domain.BoardVO;
import com.Spring1030.service.BoardService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	private BoardService service;
	
	@GetMapping("/list")
	public void list(Model model) {
		System.out.println("컨트롤러에서 list");
		model.addAttribute("list", service.getlist());
	}
	
	@GetMapping("/register")
	public void register() {	}
	
	@PostMapping("/register")
	public String register(BoardVO board, RedirectAttributes rttr) {
		System.out.println("컨트롤러에서 등록" + board);
		service.register(board);
		rttr.addFlashAttribute("result", board.getBno());
		return "redirect:/board/list";
	}
	
	@GetMapping("/get")
	public void get(@RequestParam("bno") Long bno, Model model) {
		System.out.println("컨트롤에서 /get");
		model.addAttribute("board", service.get(bno));
	}
	
	@PostMapping("/modify")
	public String modify(BoardVO board, RedirectAttributes rttr) {
		System.out.println("컨트롤러에서 수정" + board);
		if(service.modify(board)) {
			rttr.addFlashAttribute("result", "success");
		}
		return "redirect:/board/list";
	}
	
	@PostMapping("/delete") //request에 "bno" attribute가 실려옴
	public String remove(@RequestParam("bno") Long bno, RedirectAttributes rttr) {
		System.out.println("컨트롤러에서 삭제" + bno);
		if(service.remove(bno)) {
			rttr.addFlashAttribute("reuslt", "success");
		}
		return "redirect:/board/list";
	}
}
