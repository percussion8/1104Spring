package com.Spring1030.domain;

import lombok.Data;

@Data
public class SampleVO {
	int id;
	String name;
	int korea, math, eng, total;
	float avg;

}
