package com.Spring1030.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BoardVO { //테이블의 컬럼명과 1:1대응
	//JPA (java persistent Api{@Entity))
	private long bno;
	private String title;
	private String content;
	private String writer;
	private Date regDate;
	private Date updateDate;

}
